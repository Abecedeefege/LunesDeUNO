[scorekeeper](https://flack.github.io/scorekeeper) [![Build Status](https://secure.travis-ci.org/flack/scorekeeper.png?branch=master)](https://travis-ci.org/flack/scorekeeper)
======

Angular-based web app for tracking scores in card or board games
